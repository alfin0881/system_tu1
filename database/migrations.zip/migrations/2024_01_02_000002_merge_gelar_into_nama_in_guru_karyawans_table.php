<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Revisi TU #5: input nama guru/karyawan disederhanakan jadi SATU field
     * saja — TU mengetik nama lengkap beserta gelar depan & belakang
     * sekaligus (mis. "Dr. Ahmad Fauzi, S.Pd., M.M.") — bukan tiga field
     * terpisah (gelar_depan, nama, gelar_belakang) seperti sebelumnya.
     * Data lama digabung otomatis supaya tidak ada yang hilang.
     */
    public function up(): void
    {
        DB::table('guru_karyawans')->select('id', 'gelar_depan', 'nama', 'gelar_belakang')->orderBy('id')
            ->each(function ($row) {
                $namaLengkap = trim((string) $row->gelar_depan).' '.trim((string) $row->nama);
                $namaLengkap = trim($namaLengkap);
                if (! empty($row->gelar_belakang)) {
                    $namaLengkap .= ', '.trim($row->gelar_belakang);
                }

                DB::table('guru_karyawans')->where('id', $row->id)->update(['nama' => $namaLengkap]);
            });

        Schema::table('guru_karyawans', function (Blueprint $table) {
            $table->dropColumn(['gelar_depan', 'gelar_belakang']);
        });
    }

    public function down(): void
    {
        Schema::table('guru_karyawans', function (Blueprint $table) {
            $table->string('gelar_depan')->nullable()->after('nip_niy');
            $table->string('gelar_belakang')->nullable()->after('nama');
        });
    }
};
